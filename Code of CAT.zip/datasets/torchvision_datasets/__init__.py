
from .coco import CocoDetection
